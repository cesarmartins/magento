<?php
class Codazon_Filterproducts_Model_Products extends Mage_Catalog_Model_Abstract{

}