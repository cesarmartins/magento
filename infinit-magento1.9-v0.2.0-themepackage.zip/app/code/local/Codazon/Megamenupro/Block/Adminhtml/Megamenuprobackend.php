<?php  

class Codazon_Megamenupro_Block_Adminhtml_Megamenuprobackend extends Mage_Adminhtml_Block_Template {

}