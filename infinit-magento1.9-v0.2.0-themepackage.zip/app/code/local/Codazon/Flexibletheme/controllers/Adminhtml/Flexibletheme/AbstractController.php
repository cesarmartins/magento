<?php
/**
 * Copyright © 2017 Codazon, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

class Codazon_Flexibletheme_Adminhtml_Flexibletheme_AbstractController extends Mage_Adminhtml_Controller_Action
{
	
	
}