<?php

class Codazon_Flexibletheme_Block_Adminhtml_Form_Renderer_Innerfieldset extends Varien_Data_Form_Element_Abstract
{
    
}
