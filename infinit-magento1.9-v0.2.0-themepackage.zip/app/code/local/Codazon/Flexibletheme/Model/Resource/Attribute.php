<?php
class Codazon_Flexibletheme_Model_Resource_Attribute extends Mage_Eav_Model_Resource_Entity_Attribute
{
    
}