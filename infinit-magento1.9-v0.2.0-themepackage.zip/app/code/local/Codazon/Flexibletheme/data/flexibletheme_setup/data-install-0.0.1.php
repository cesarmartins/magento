<?php
/**
 * Copyright © 2018 Codazon, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

$model = Mage::getSingleton('flexibletheme/import');
$model->importAll();
?>